<?php
/**
* Plugin Name: Botslot
* Plugin URI: https://pgslot898.com/
* Description: บอทสล็อต PG ใส่ [botslot] หน้าที่ต้องการได้เลย
* Version: 0.1
* Author: PGSLOT
* Author URI: https://pgslot898.com/
 */
?>
<?php
defined( 'ABSPATH' ) || exit;
define( 'bot_file',                  __FILE__ );
define( 'bot_url',                   plugin_dir_url( bot_file ) );
define( 'bot_access',            bot_file . 'scanslot/' );

 if( !defined('THEME_IMG_PATH')){
   define( 'THEME_IMG_PATH', get_stylesheet_directory_uri() . '/images' );
  }

function botslot()
{
return '
<link rel="stylesheet" href="/wp-content/plugins/botslot/scanslot/styleGameBox.css">
<script src="/wp-content/plugins/botslot/jquery.min.js"></script>
<link rel="stylesheet" href="/wp-content/plugins/botslot/public/css/bootstrap.min.css">
<script src="/wp-content/plugins/botslot/game.js"></script>

<div class="game-bot">
<div class="row">
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:0 auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">

<div class="g-cover" style="background-image: url(/wp-content/plugins/botslot/scanslot/img/cover/96.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/96.webp);"></div>
<div class="g-bg" style="background: rgb(51, 4, 49);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(51, 4, 49);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/96.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/96.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Wild Bounty Showdown</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_96 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.75%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x5000</div>
<div class="title">อัตราชนะสูงสุดอัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/97.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/97.webp);"></div>
<div class="g-bg" style="background: rgb(51, 4, 49);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(51, 4, 49);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/97.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/97.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Wild Coaster</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_97 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.71%</div>
<div class="title">RTP</div>
 </div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/79.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/79.webp);"></div>
<div class="g-bg" style="background: rgb(51, 4, 49);"></div>
<div class="g-detail">
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/2.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Win Win Fish Prawn Crab</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_79 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.72%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/1.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/1.webp);"></div>
<div class="g-bg" style="background: rgb(51, 4, 49);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(51, 4, 49);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/1.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/1.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Lucky Piggy</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_1 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.79%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/2.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/2.webp);"></div>
<div class="g-bg" style="background: rgb(6, 47, 130);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(6, 47, 130);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/2.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/2.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Win Win Fish Prawn Crab</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_2 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">LOW</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.72%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/3.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/3.webp);"></div>
<div class="g-bg" style="background: rgb(20, 77, 0);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(20, 77, 0);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/3.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/3.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Battleground Royale</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_3 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.75%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
 </div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/4.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/4.webp);"></div>
<div class="g-bg" style="background: rgb(117, 33, 5);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(117, 33, 5);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/4.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/4.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Rooster Rumble</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_4 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.75%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/5.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/5.webp);"></div>
<div class="g-bg" style="background: rgb(197, 121, 16);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(197, 121, 16);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/5.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/5.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Butterfly Blossom</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_5 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.74%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/6.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/6.webp);"></div>
<div class="g-bg" style="background: rgb(51, 4, 49);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(51, 4, 49);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/6.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/6.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Destiny of Sun & Moon</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_6 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.8%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>
 
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/7.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/7.webp);"></div>
<div class="g-bg" style="background: rgb(117, 45, 16);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(117, 45, 16);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/7.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/7.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Garuda Gems</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_7 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.77%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
 <img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/8.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/8.webp);"></div>
<div class="g-bg" style="background: rgb(168, 44, 34);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(168, 44, 34);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/8.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/8.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Fortune Tiger</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_8 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.81%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x2500</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/9.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/9.webp);"></div>
<div class="g-bg" style="background: rgb(64, 29, 130);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(64, 29, 130);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/9.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/9.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Mask Carnival</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_9 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.7%</div>
<div class="title">RTP</div>
</div>
 <div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/10.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/10.webp);"></div>
<div class="g-bg" style="background: rgb(197, 121, 16);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(197, 121, 16);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/10.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/10.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Emoji Riches</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_10 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
 </div>
<div>
<div class="value">96.78%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x25000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/11.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/11.webp);"></div>
<div class="g-bg" style="background: rgb(51, 4, 49);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(51, 4, 49);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/11.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/11.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Farm Invaders</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_11 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
 <div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.68%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/12.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/12.webp);"></div>
<div class="g-bg" style="background: rgb(51, 4, 49);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(51, 4, 49);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/12.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/12.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Spirited Wonders</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
 <div class="pb_12 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.7%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/13.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/13.webp);"></div>
<div class="g-bg" style="background: rgb(120, 32, 53);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(120, 32, 53);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/13.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/13.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Legendary Monkey King</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_13 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.71%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/14.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/14.webp);"></div>
<div class="g-bg" style="background: rgb(96, 60, 37);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(96, 60, 37);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/14.webp);"></div>
</div>
<div class="detailtop">
 <div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/14.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Buffalo Win</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_14 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.71%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x25000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/15.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/15.webp);"></div>
<div class="g-bg" style="background: rgb(216, 115, 77);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(216, 115, 77);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/15.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/15.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Supermarket Spree</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_15 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.71%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x25000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/16.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/16.webp);"></div>
<div class="g-bg" style="background: rgb(51, 4, 49);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(51, 4, 49);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/16.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/16.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Raider Janes Crypt of Fortune</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_16 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.75%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/17.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/17.webp);"></div>
<div class="g-bg" style="background: rgb(117, 33, 5);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(117, 33, 5);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/17.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/17.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Groundhog Harvest</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_17 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.71%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/18.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/18.webp);"></div>
<div class="g-bg" style="background: rgb(6, 47, 130);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(6, 47, 130);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/18.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/18.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Mermaid Riches</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_18 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.71%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/19.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/19.webp);"></div>
<div class="g-bg" style="background: rgb(217, 88, 34);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(217, 88, 34);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/19.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/19.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Sushi Oishi</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_19 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.71%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/20.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/20.webp);"></div>
<div class="g-bg" style="background: rgb(90, 64, 2);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(90, 64, 2);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/20.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/20.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Heist Stakes</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_20 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.72%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x30000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
 <div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/21.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/21.webp);"></div>
<div class="g-bg" style="background: rgb(89, 2, 92);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(89, 2, 92);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/21.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/21.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Wild Bandito</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_21 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.73%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x25000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
 <div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/22.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/22.webp);"></div>
<div class="g-bg" style="background: rgb(201, 69, 169);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(201, 69, 169);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/22.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/22.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Candy Bonanza</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_22 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.72%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/23.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/23.webp);"></div>
<div class="g-bg" style="background: rgb(45, 15, 63);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(45, 15, 63);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/23.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/23.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Majestic Treasures</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_23 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.68%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/24.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/24.webp);"></div>
<div class="g-bg" style="background: rgb(81, 46, 88);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(81, 46, 88);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/24.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/24.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Bali Vacation</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_24 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
 <div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.71%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/25.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/25.webp);"></div>
<div class="g-bg" style="background: rgb(112, 1, 0);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(112, 1, 0);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/25.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/25.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Fortune Ox</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_25 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.75%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x2000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/26.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/26.webp);"></div>
<div class="g-bg" style="background: rgb(51, 4, 49);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(51, 4, 49);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/26.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/26.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Guardians of Ice & Fire</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_26 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.7%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/27.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/27.webp);"></div>
<div class="g-bg" style="background: rgb(46, 26, 51);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(46, 26, 51);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/27.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/27.png"></div>
 </div>
<div class="d-note">
<b>สูตรสล็อต Galactic Gems</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_27 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.74%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/28.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/28.webp);"></div>
<div class="g-bg" style="background: rgb(8, 34, 95);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(8, 34, 95);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/28.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/28.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Jack Frosts Winter</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_28 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.7%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/29.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/29.webp);"></div>
 <div class="g-bg" style="background: rgb(103, 3, 29);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(103, 3, 29);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/29.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/29.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Jewels of Prosperity</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_29 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.73%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/30.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/30.webp);"></div>
<div class="g-bg" style="background: rgb(223, 100, 0);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(223, 100, 0);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/30.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/3.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Queen of Bounty</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_30 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.74%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/31.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/31.webp);"></div>
<div class="g-bg" style="background: rgb(71, 17, 106);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(71, 17, 106);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/31.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/31.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Vampires Charm</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_31 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.75%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/32.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/32.webp);"></div>
<div class="g-bg" style="background: rgb(51, 4, 49);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(51, 4, 49);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/32.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/32.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Secrets of Cleopatra</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_32 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.74%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/33.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/33.webp);"></div>
<div class="g-bg" style="background: rgb(93, 15, 67);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(93, 15, 67);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/33.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/33.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Circus Delight</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_33 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.7%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>
 
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/34.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/34.webp);"></div>
<div class="g-bg" style="background: rgb(35, 11, 126);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(35, 11, 126);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/34.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/34.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Genies 3 Wishes</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_34 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.75%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
 <img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/35.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/35.webp);"></div>
<div class="g-bg" style="background: rgb(46, 36, 88);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(46, 36, 88);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/35.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/35.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Wild Fireworks</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_35 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.75%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
 </div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/36.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/36.webp);"></div>
<div class="g-bg" style="background: rgb(60, 26, 54);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(60, 26, 54);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/36.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/36.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Phoenix Rises</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_36 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.7%</div>
<div class="title">RTP</div>
</div>
 <div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/37.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/37.webp);"></div>
<div class="g-bg" style="background: rgb(0, 149, 133);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(0, 149, 133);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/37.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/37.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Mahjong Ways 2</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_37 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.95%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/38.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/38.webp);"></div>
<div class="g-bg" style="background: rgb(152, 11, 124);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(152, 11, 124);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/38.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/38.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Candy Burst</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_38 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.95%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x15000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/39.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/39.webp);"></div>
<div class="g-bg" style="background: rgb(72, 162, 32);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(72, 162, 32);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/39.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/39.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Shaolin Soccer</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_39 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.93%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x4000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/40.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/40.webp);"></div>
<div class="g-bg" style="background: rgb(226, 54, 45);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(226, 54, 45);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/40.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/40.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Bikini Paradise</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_40 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.95%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/41.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/41.webp);"></div>
<div class="g-bg" style="background: rgb(55, 31, 105);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(55, 31, 105);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/41.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/41.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Reel Love</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_41 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.96%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x30000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/42.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/42.webp);"></div>
<div class="g-bg" style="background: rgb(103, 2, 9);"></div>
<div class="g-detail">
 <div class="g-blur" style="background: rgb(103, 2, 9);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/42.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/42.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Fortune Mouse</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_42 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.96%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x1000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/43.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/43.webp);"></div>
<div class="g-bg" style="background: rgb(89, 52, 68);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(89, 52, 68);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/43.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/43.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Dragon Hatch</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_43 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.83%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x15000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/44.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/44.webp);"></div>
<div class="g-bg" style="background: rgb(148, 18, 8);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(148, 18, 8);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/44.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/44.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Mahjong Ways</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_44 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.92%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x25000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
 </div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/45.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/45.webp);"></div>
<div class="g-bg" style="background: rgb(83, 3, 6);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(83, 3, 6);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/45.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/45.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Flirting Scholar</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_45 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">97.44%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x22500</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/46.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/46.webp);"></div>
<div class="g-bg" style="background: rgb(36, 22, 76);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(36, 22, 76);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/46.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/46.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Muay Thai Champion</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_46 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">97.38%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x15000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/47.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/47.webp);"></div>
<div class="g-bg" style="background: rgb(51, 4, 49);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(51, 4, 49);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/47.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/47.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Dragon Tiger Luck</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_47 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">LOW</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.94%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x200</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/48.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/48.webp);"></div>
<div class="g-bg" style="background: rgb(46, 20, 20);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(46, 20, 20);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/48.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/48.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Ninja vs Samurai</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_48 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">97.44%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x15000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
 <div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/49.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/49.webp);"></div>
<div class="g-bg" style="background: rgb(20, 77, 0);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(20, 77, 0);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/49.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/49.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Leprechaun Riches</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_49 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">97.35%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/50.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/50.webp);"></div>
<div class="g-bg" style="background: rgb(206, 34, 57);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(206, 34, 57);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/50.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/50.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Double Fortune</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_50 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.22%</div>
 <div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/51.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/51.webp);"></div>
<div class="g-bg" style="background: rgb(160, 46, 36);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(160, 46, 36);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/51.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/51.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Emperors Favour</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_51 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.03%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x10000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/52.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/52.webp);"></div>
<div class="g-bg" style="background: rgb(0, 112, 223);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(0, 112, 223);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/52.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/52.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต The Great Icescape</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_52 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.32%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/53.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/53.webp);"></div>
<div class="g-bg" style="background: rgb(37, 83, 19);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(37, 83, 19);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/53.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/53.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Jungle Delight</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
 </div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_53 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.03%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x15000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/54.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/54.webp);"></div>
<div class="g-bg" style="background: rgb(44, 20, 13);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(44, 20, 13);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/54.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/54.png"></div>
 </div>
<div class="d-note">
<b>สูตรสล็อต Captain’s Bounty</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_54 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.15%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x30000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/55.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/55.webp);"></div>
<div class="g-bg" style="background: rgb(95, 129, 229);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(95, 129, 229);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/55.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/55.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Three Monkeys</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_55 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.14%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x1800</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/56.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/56.webp);"></div>
 <div class="g-bg" style="background: rgb(69, 2, 91);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(69, 2, 91);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/56.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/56.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Ganesha Gold</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_56 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.08%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;"> 
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/57.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/57.webp);"></div>
<div class="g-bg" style="background: rgb(105, 68, 110);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(105, 68, 110);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/57.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/57.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Journey To The Wealth</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_57 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.39%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x8000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
 </div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/58.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/58.webp);"></div>
<div class="g-bg" style="background: rgb(31, 17, 4);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(31, 17, 4);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/58.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/58.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Symbols of Egypt</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_58 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">95.71%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x1800</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/59.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/59.webp);"></div>
<div class="g-bg" style="background: rgb(178, 24, 24);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(178, 24, 24);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/59.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/59.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Piggy Gold</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_59 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">95.86%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x5000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/60.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/60.webp);"></div>
<div class="g-bg" style="background: rgb(21, 86, 43);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(21, 86, 43);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/60.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/60.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Gem Saviour Sword</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_60 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">95.54%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x400</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/61.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/61.webp);"></div>
<div class="g-bg" style="background: rgb(197, 121, 16);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(197, 121, 16);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/61.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/61.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Win Win Won</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_61 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">94.14%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x2600</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
 <img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/62.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/62.webp);"></div>
<div class="g-bg" style="background: rgb(250, 131, 1);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(250, 131, 1);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/62.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/62.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Fortune Gods</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_62 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">95.04%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x3600</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
 <div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/63.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/63.webp);"></div>
<div class="g-bg" style="background: rgb(51, 4, 49);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(51, 4, 49);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/63.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/63.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Santa’s Gift Rush</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_63 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">LOW</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.36%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x9000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/64.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/64.webp);"></div>
<div class="g-bg" style="background: rgb(118, 72, 125);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(118, 72, 125);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/64.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/64.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Hip Hop Panda</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_64 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
 </div>
<div>
<div class="value">95.75%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x600</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/65.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/65.webp);"></div>
<div class="g-bg" style="background: rgb(13, 22, 93);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(13, 22, 93);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/65.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/65.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Prosperity Lion</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_65 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
 <div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">95.77%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x800</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/66.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/66.webp);"></div>
<div class="g-bg" style="background: rgb(144, 107, 87);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(144, 107, 87);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/66.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/66.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Legend of Hou Yi</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
 <div class="pb_66 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">LOW</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">95.78%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x5000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/67.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/67.webp);"></div>
<div class="g-bg" style="background: rgb(15, 18, 70);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(15, 18, 70);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/67.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/67.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Mr. Hallow-Win</b>
 <span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_67 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">95.86%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x5000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/68.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/68.webp);"></div>
<div class="g-bg" style="background: rgb(99, 10, 57);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(99, 10, 57);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/68.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/68.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Hood vs Wolf</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_68 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">95.39%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x4000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/69.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/69.webp);"></div>
<div class="g-bg" style="background: rgb(85, 1, 0);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(85, 1, 0);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/69.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/69.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Hotpot</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_69 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">95.83%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x15000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/70.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/70.webp);"></div>
<div class="g-bg" style="background: rgb(63, 152, 136);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(63, 152, 136);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/70.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/70.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Dragon Legend</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_70 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">97.15%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x3000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/71.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/71.webp);"></div>
<div class="g-bg" style="background: rgb(48, 2, 4);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(48, 2, 4);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/71.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/71.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Baccarat Deluxe</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_71 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">LOW</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">98.94%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x12</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
 </div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/72.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/72.webp);"></div>
<div class="g-bg" style="background: rgb(12, 63, 126);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(12, 63, 126);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/72.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/72.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Gem Saviour</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_72 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.82%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x500</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/73.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/73.webp);"></div>
<div class="g-bg" style="background: rgb(92, 8, 118);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(92, 8, 118);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/73.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/73.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Wizdom Wonders</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_73 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">94.47%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x3000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/74.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/74.webp);"></div>
<div class="g-bg" style="background: rgb(106, 127, 249);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(106, 127, 249);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/74.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/74.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Plushie Frenzy</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_74 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">94.82%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x10000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
 </div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/75.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/75.webp);"></div>
<div class="g-bg" style="background: rgb(45, 95, 80);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(45, 95, 80);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/75.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/75.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Medusa</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_75 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">95.29%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x400</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
 <img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/76.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/76.webp);"></div>
<div class="g-bg" style="background: rgb(8, 52, 63);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(8, 52, 63);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/76.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/76.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Medusa II</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_76 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">94.96%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x2000</div>
<div class="title">อัตราชนะสูงสุด</div>
 </div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/77.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/77.webp);"></div>
<div class="g-bg" style="background: rgb(21, 37, 75);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(21, 37, 75);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/77.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/77.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Honey Trap of Diao Chan</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_77 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.96%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/78.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/78.webp);"></div>
<div class="g-bg" style="background: rgb(196, 143, 3);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(196, 143, 3);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/78.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/78.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Tree Of Fortune</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_78 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">95.01%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x5000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
 </div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/80.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/80.webp);"></div>
<div class="g-bg" style="background: rgb(148, 18, 8);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(148, 18, 8);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/80.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/80.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Ganesha Fortune</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_80 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.72%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">7524</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/81.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/81.webp);"></div>
<div class="g-bg" style="background: rgb(196, 143, 3);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(196, 143, 3);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/81.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/81.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Dreams of Macau</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_81 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.73%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/82.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/82.webp);"></div>
<div class="g-bg" style="background: rgb(223, 100, 0);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(223, 100, 0);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/82.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/82.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Caishen Wins</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_82 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.92%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x4936</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
 <div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/83.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/83.webp);"></div>
<div class="g-bg" style="background: rgb(8, 34, 95);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(8, 34, 95);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/83.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/83.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Gem Saviour Conquest</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_83 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.92%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
 <div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/84.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/84.webp);"></div>
<div class="g-bg" style="background: rgb(31, 17, 4);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(31, 17, 4);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/84.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/84.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Egypt’s Book of Mystery</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_84 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.74%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x10000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/85.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/85.webp);"></div>
<div class="g-bg" style="background: rgb(144, 107, 87);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(144, 107, 87);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/85.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/85.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Oriental Prosperity </b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_85 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.51%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x20000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/86.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/86.webp);"></div>
<div class="g-bg" style="background: rgb(129, 22, 51);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(129, 22, 51);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/86.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/86.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Cocktail Nights</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_86 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
 <div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.75%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/87.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/87.webp);"></div>
<div class="g-bg" style="background: rgb(85, 1, 0);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(85, 1, 0);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/87.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/87.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Jurassic Kingdom</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_87 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.72%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/88.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/88.webp);"></div>
<div class="g-bg" style="background: rgb(196, 143, 3);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(196, 143, 3);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/88.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/88.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Ways of the Qilin</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_88 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.69%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/89.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/89.webp);"></div>
<div class="g-bg" style="background: rgb(118, 72, 125);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(118, 72, 125);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/89.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/89.png"></div>
 </div>
<div class="d-note">
<b>สูตรสล็อต Lucky Neko</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_89 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">97.02%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/90.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/90.webp);"></div>
<div class="g-bg" style="background: rgb(160, 46, 36);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(196, 143, 3);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/90.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/90.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Opera Dynasty</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_90 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.74%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x35000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/91.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/91.webp);"></div>
 <div class="g-bg" style="background: rgb(69, 2, 91);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(69, 2, 91);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/91.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/91.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Thai River Wonders</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_91 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.71%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/92.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/92.webp);"></div>
<div class="g-bg" style="background: rgb(44, 20, 13);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(44, 20, 13);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/92.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/92.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Treasures of Aztec</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_92 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.71%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x100000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/93.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/93.webp);"></div>
<div class="g-bg" style="background: rgb(90, 64, 2);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(90, 64, 2);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/93.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/93.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Rise Of Apollo</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_93 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.78%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/94.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/94.webp);"></div>
<div class="g-bg" style="background: rgb(64, 29, 130);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(64, 29, 130);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/94.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/94.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต Crypto Gold</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_94 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">HIGH</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.71%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x50000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-4 mt-3 mb-3">
<div style="width: 308px;height: 400px;margin:auto">
<div class="game-box trynow" style="display: block;">
<div class="gg-bs">
<div class="g-cover" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/95.webp);"></div>
<div class="g-reflect" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/95.webp);"></div>
<div class="g-bg" style="background: rgb(196, 143, 3);"></div>
<div class="g-detail">
<div class="g-blur" style="background: rgb(196, 143, 3);">
<div class="coverimg" style="background: url(/wp-content/plugins/botslot/scanslot/img/cover/95.webp);"></div>
</div>
<div class="detailtop">
<div class="d-icon">
<div><img src="/wp-content/plugins/botslot/scanslot/img/game/95.png"></div>
</div>
<div class="d-note">
<b>สูตรสล็อต The Queens Banquet</b>
<span class="description1">สูตรส่งตรงจาก PG SOFT</span>
</div>
</div>
<div class="progress md-progress mt-2 mb-2">
<div class="pb_95 progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
</div><div class="detailbottom">
<div class="detailrow r1">
<div>
<div class="value">MEDIUM</div>
<div class="title">ความยากของเกม</div>
</div>
<div>
<div class="value">96.71%</div>
<div class="title">RTP</div>
</div>
<div>
<div class="value">x9000</div>
<div class="title">อัตราชนะสูงสุด</div>
</div>
</div>
<div class="detailrow r2">
<div class="cert">
<div class="image">
<img src="/wp-content/plugins/botslot/scanslot/img/bmm.png">
<img src="/wp-content/plugins/botslot/scanslot/img/GA.png">
</div>
<div class="title">ใบรับรอง</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


</div>
</div> 
</div>

</div>';
}

add_shortcode('botslot', 'botslot')
 
?>