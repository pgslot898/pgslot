$(document).ready(function () {
    for (let i = 1; i < 99; i++) {
        get_process(i);
    }
   function get_process(id) {
        const card = $(`.c_${id}`);
        const textResult = $(`.tr_${id}`);
        const textResultt = $(`.ttr_${id}`);
        const image = $(`.image_${id}`);
        const progressBar = $(`.pb_${id}`);
        textResult.html('กรุณารอซักครู่...');
        progressBar.html("ระบบกำลังสแกนเกม...");
        setTimeout(function () {
            $(".image").addClass("animated flipInX");
            let rand = Math.floor(Math.random() * (100 - 20 + 1)) + 20;
            progressBar.html(rand + "%");
            textResult.html('อัตราชนะ ' + rand + "%"
            );
            if (rand <= 25) {
                textResultt.html('ไม่ควรเล่น');
                textResultt.addClass("text-danger");
                progressBar.addClass("bg-danger");
                image.addClass("filter");
                progressBar.css("width", +rand + "%");
            } else if (rand <= 50) {
                textResultt.html( 'เล่นได้');
                textResultt.addClass("text-warning");
                progressBar.addClass("bg-warning");
                progressBar.css("width", +rand + "%");
            } else if (rand <= 90) {
                textResultt.html('FREE SPIN');
                textResultt.addClass("text-info");
                progressBar.addClass("bg-info");
                progressBar.css("width", +rand + "%");
            } else if (rand <= 100) {
                textResultt.html('แจ็คพอต');
                textResultt.addClass("text-success");
                progressBar.addClass("bg-success");
                progressBar.css("width", +rand + "%");
                card.addClass("animated tada infinite");
            }
        }, 1000);
        setTimeout(() => {
            $(".image").removeClass("animated flipInX");
        }, 1250);
    }
});